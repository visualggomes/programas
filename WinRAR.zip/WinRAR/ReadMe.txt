   Este arquivo cont�m o gerenciador de arquivos multifuncional WinRAR.

   Recursos do WinRAR:

 * O WinRAR introduz um algoritmo de compress�o original. Ele fornece
    altas taxas de compress�o em arquivos execut�veis, bibliotecas de 
    objeto, grandes arquivos de texto, etc.

 * O formato interno do RAR n�o limita a compress�o e o tamanho do arquivo 
   bem como um n�mero de arquivos no arquivo comprimido. Estes valores podem 
   ser limitados pelo arquivo e pelo sistema operacional como tamb�m pela 
   mem�ria dispon�vel.

 * O WinRAR fornece suporte completo para arquivos RAR e ZIP 2.0 e pode
   descomprimir arquivos como 7Z, ARJ, BZ2, CAB, GZ, ISO, JAR, LZ, LZH,
   TAR, UUE, XZ, Z, ZST.

 * O WinRAR oferece novas facilidades e fun��es como uma interface gr�fica 
   interativa e uma interface de linha de comandos.

 * O WinRAR fornece a funcionalidade de criar arquivos 's�lidos', que
   poder�o aumentar a taxa de compress�o entre 10% - 50% a mais sobre
   os m�todos mais comuns, particularmente quando se comprime um grande 
   n�mero de pequenos arquivos.

 * O WinRAR pode criar e alterar arquivos SFX personaliz�veis.

 * O WinRAR pode criar arquivos de volumes m�ltiplos como SFX.

 * O registro de recupera��o opcional permite proteger arquivos de danos.

 * O WinRAR oferece fun��es de servi�o, como criptografia de arquivos,
   adicionar coment�rios para arquivos comprimidos e preservar a
   seguran�a de arquivos NTFS.
